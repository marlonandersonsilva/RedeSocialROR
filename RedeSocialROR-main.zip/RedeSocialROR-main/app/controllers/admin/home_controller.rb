class Admin::HomeController < AdminController

  def index
  end
end
