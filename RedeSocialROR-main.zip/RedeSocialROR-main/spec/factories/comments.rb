FactoryBot.define do
  factory :comment do
    body { "Que post legal" }
  end
end
