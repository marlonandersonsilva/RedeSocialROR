FactoryBot.define do
  factory :post do
    body { "Integer tincidunt efficitur purus, ac lobortis
      morbi tristique senectus et netus et malesuada fames ac
      turpis egestas. Praesent vel ex tincidunt, varius nisl consectetur,
      dapibus orci."
    }
  end
end
